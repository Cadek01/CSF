#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <assert.h>
#include "fixedpoint.h"

Fixedpoint fixedpoint_create(uint64_t whole) {
  // define this.whole as whole, this.frac as 0
  // define the remaining fields as false (neg, err, overflow tags)
  Fixedpoint fixedpoint = {whole, 0, 0, 0, 0, 0, 0, 0};
  return fixedpoint;
}

Fixedpoint fixedpoint_create2(uint64_t whole, uint64_t frac) {
  // define this.whole as whole, this.frac as frac
  // define the remaining fields as false (neg, err, overflow tags)
  Fixedpoint fixedpoint = {whole, frac, 0, 0, 0, 0, 0, 0};
  return fixedpoint;  
}

Fixedpoint fixedpoint_create_from_hex(const char *hex) {
  // assume all fields are zero to start
  uint64_t whole = 0, frac = 0;
  int neg = 0, err = 0, is_frac = 0;
  // initialize error pointer
  int *err_ptr = &err;
  // get length of hex string
  int len_hex = strlen(hex);

  // if hex starts with '-', make hex start off with next char, lower len_hex to compensate, and mark fixedpoint as neg
  if (*hex == '-') {
    neg = 1;
    ++hex;
    --len_hex;
  }

  // detect where period in hex string is, everything to right represents whole and everything to left represents frac
  for (int i = 0; i < len_hex; i++) {
    if (hex[i] == '.') {
      is_frac = 1;
      whole = hex_to_dec(hex + i - 1, i, 1, err_ptr);
      frac = hex_to_dec(hex + i + 1, len_hex - i - 1, 0, err_ptr);
    }
  }

  // if no period detected, assume the whole hex string represents whole
  if (!is_frac) whole = hex_to_dec(hex, len_hex, 1, err_ptr);

  // create fixedpoint, mark neg and err fields by their neg and err field status trackers used in this function
  Fixedpoint fixedpoint = fixedpoint_create2(whole, frac);
  fixedpoint.neg = neg;
  fixedpoint.err = err;
  return fixedpoint;
}

uint64_t fixedpoint_whole_part(Fixedpoint val) {
  return val.whole;
}

uint64_t fixedpoint_frac_part(Fixedpoint val) {
  return val.frac;
}

/* Fixedpoint fixedpoint_add(Fixedpoint left, Fixedpoint right) {
  if (left.neg && !right.neg) {
    left = fixedpoint_negate(left);
    return fixedpoint_sub(right, left);
  }

  if (!left.neg && right.neg) {
    right = fixedpoint_negate(right);
    return fixedpoint_sub(left, right);
  }

  if (left.neg && right.neg) {
    left = fixedpoint_negate(left);
    right = fixedpoint_negate(right);
    return fixedpoint_negate( fixedpoint_add(left, right));
  }

  // start with frac:
  // create pointer to track any carry-over needed
  uint64_t carry_over = 0;
  uint64_t* carry_over_ptr = &carry_over;
  // get frac_sum, modified cary_over pointer
  uint64_t frac_sum = bitwise_sum(carry_over_ptr, left.frac, right.frac);
  // move on to whole:
  uint64_t whole_sum = carry_over + left.whole + right.whole; 
  // return overall fixedpoint
  Fixedpoint sum = fixedpoint_create2(whole_sum, frac_sum);

  // WITH INT ADDITION - doesnt work
  if ( ( (left.frac >> 63) & 1) && ( (right.frac >> 63) & 1) ) {
    left.frac -= 1UL << 63;
    right.frac -= 1UL << 63;
    carry_over = 1;
  }
  Fixedpoint sum = fixedpoint_create2(left.whole + right.whole + carry_over, left.frac + right.frac);
  if (!fixedpoint_is_zero(left) && !fixedpoint_is_zero(right)) {
    if ( (fixedpoint_compare(left, sum) != -1) || (fixedpoint_compare(right, sum) != -1)) {
      sum.pos_over = 1;
    }
  }
  return sum; 
}   */

Fixedpoint fixedpoint_add(Fixedpoint left, Fixedpoint right) {
  	
  // -|left| + |right| = |right| - |left|
  if (left.neg && !right.neg) {
    // Fixedpoint left_copy = fixedpoint_negate(left);
    left.neg = 0;
    return fixedpoint_sub(right, left);
  }

  // |left| + -|right| = |left| - |right|
  if (!left.neg && right.neg) {
    // Fixedpoint right_copy = fixedpoint_negate(right);
    right.neg = 0;
    return fixedpoint_sub(left, right);
  }

  // -|left| + -|right| = -(|left| + |right|)
  if (left.neg && right.neg) {
    // Fixedpoint left_copy = fixedpoint_negate(left);
    // Fixedpoint right_copy = fixedpoint_negate(right);
    // return fixedpoint_negate( fixedpoint_add(left_copy, right_copy));
    left.neg = 0;
    right.neg = 0;
    Fixedpoint res = fixedpoint_add(left, right);
    res.neg = 1;
    res.neg_over = res.pos_over;
    res.pos_over = 0;
    return res;
  }

  // initialize variables to keep track of any needed carrying and overflow
  /* uint64_t whole_carry = 0, frac_carry = 0, overflow = 0;
  uint64_t *frac_carry_ptr = &frac_carry;
  uint64_t *overflow_ptr = &overflow;
  Fixedpoint addend1 = left;
  Fixedpoint addend2 = right;

  // get frac first
  uint64_t frac_sum = get_add_val(left.frac, right.frac, frac_carry_ptr);
  // if carrying over is needed, add 1 to addend1.whole
  if (frac_carry) {
    addend1.whole = get_add_val(left.whole, frac_carry, overflow_ptr);
  }

  // get whole next
  uint64_t whole_sum = get_add_val(addend1.whole, addend2.whole, overflow_ptr); 
  Fixedpoint sum = fixedpoint_create2(whole_sum, frac_sum);
  // if the whole needs carrying over, overflow has occured
  sum.pos_over = overflow;*/

  uint64_t frac_sum = left.frac + right.frac;
  uint64_t whole_sum = 0;
  int over = 0;

  if (frac_sum < right.frac) whole_sum += 1UL;
  whole_sum += left.whole;
  if (whole_sum < left.whole) over = 1;

  whole_sum += right.whole;
  if (whole_sum < right.whole) over = 1;

  Fixedpoint sum = fixedpoint_create2(whole_sum, frac_sum);
  sum.pos_over = over;

  return sum;
}

Fixedpoint fixedpoint_sub(Fixedpoint left, Fixedpoint right) {
  Fixedpoint diff, temp;
  uint64_t whole_diff = 0, frac_diff = 0;
  int neg = 0;

  // |left| - -|right| = |left| + |right|
  if (!left.neg && right.neg) {
    // right = fixedpoint_negate(right);
    right.neg = 0;
    return fixedpoint_add(left, right);
  }

  // -|left| - |right| = -(|left| + |right|)
  if (left.neg && !right.neg) {
    // left = fixedpoint_negate(left);
    left.neg = 0;
    Fixedpoint diff = fixedpoint_add(left, right);
    diff.neg = 1;
    diff.neg_over = diff.pos_over;
    diff.pos_over = 0;
    return diff;
  }

  // -|left| - -|right| = -(|left| - |right|)
  if (left.neg && right.neg) {
    /* temp = fixedpoint_negate(right);
    right = fixedpoint_negate(left);
    left = temp; */
    left.neg = 0;
    right.neg = 0;
    Fixedpoint diff = fixedpoint_sub(right, left);
    return diff;
    // return fixedpoint_negate(fixedpoint_sub(left, right));
  }

  // if left and right are equal, return 0
  if (!fixedpoint_compare(left, right)) return fixedpoint_create(0);

  // if left < right, result is negative; mark as such and switch left and right to get a positive result from substraction
  if ((left.whole < right.whole) || ((left.whole == right.whole) && (left.frac < right.frac))) {
    Fixedpoint diff = fixedpoint_sub(right, left);
    diff.neg = 1;
    return diff;
  }

  // get whole difference
  whole_diff = left.whole - right.whole;

  // if borrowing over from whole is necessary, do so
  if (right.frac > left.frac) {
    frac_diff = right.frac - left.frac;
    frac_diff = (~0UL) - frac_diff + 1;
    whole_diff--;
  }

  else frac_diff = left.frac - right.frac;

  // create difference
  diff = fixedpoint_create2(whole_diff, frac_diff);

  // change neg field of difference to match the neg tracker used in this function
  if (neg) diff = fixedpoint_negate(diff);

  // return difference
  return diff;
}

Fixedpoint fixedpoint_negate(Fixedpoint val) {
  int temp;

  // if value is equal to zero, do nothing
  if (fixedpoint_is_zero(val)) return val;
  
  // set positive value to negative, negative values to positive
  val.neg = val.neg ? 0 : 1;

  // switch positive overflow and negative overflow status
  /* if (val.pos_over || val.neg_over) {
    temp = val.pos_over;
    val.pos_over = val.neg_over;
    val.neg_over = temp;
  } */

  // switch positive underflow and negative underflow status
  if (val.pos_under || val.neg_under) {
    temp = val.pos_under;
    val.pos_under = val.neg_under;
    val.neg_under = temp;
  }
  return val;
}

Fixedpoint fixedpoint_halve(Fixedpoint val) {
  uint64_t halved_whole = 0, halved_frac = 0;
  int whole_is_odd = val.whole & 1;

  // complication #1 with base case: frac looses information when shifted over by 1 bit because already 64th bit had information in it
  // need to mark as underflow (pos if val is pos, neg is val is neg)
  if (val.frac & 1) {
	  if (fixedpoint_is_neg(val)) val.neg_under = 1;
	  else val.pos_under = 1;
  }
  // base case: whole can get halved, fraction can get halved indepedently of each other (no carrying over)
  halved_whole = val.whole >> 1;
  halved_frac = val.frac >> 1;

  // complication #2 with base case: when whole get cut, 0.5 may need to be carried over to frac
  if (whole_is_odd) halved_frac += 1UL << 63;

  // else, base case, do nothing
  // return halved fixedpoint
  Fixedpoint half = fixedpoint_create2(halved_whole, halved_frac);

  // half inherits underflow statuses of its progenitor fixedpoint and negative status
  half.neg_under = val.neg_under;
  half.pos_under = val.pos_under;
  half.neg = val.neg;
  return half;
}

Fixedpoint fixedpoint_double(Fixedpoint val) {
  // return fixedpoint_add(val, val);

  // create tracking for carrying and overflow
  uint64_t carry = 0, overflow = 0;

  // recognize need to carry over if last bit of frac is 1
  if (val.frac & (1UL << 63)) {
    carry = 1UL;
  }

  // recognize that overflow will occur if last bit of whole is 1
  if (val.whole & (1UL << 63)) {
    overflow = 1UL;
  }

  // do bit shifting to double
  val.frac = val.frac << 1;
  val.whole = val.whole << 1;

  // add carry to whole;
  val.whole += carry;

  // set overflow statuses, either positive or neg based on neg status of value doubled
  if (overflow) {
    if (fixedpoint_is_neg(val)) val.neg_over = 1;
    else val.pos_over = 1;
  }

  // return val
  return val;
}

int fixedpoint_compare(Fixedpoint left, Fixedpoint right) {
  // if values are equal, return 0
  if ( (left.whole == right.whole) && (left.frac == right.frac) && (left.neg == right.neg)) return 0;

  // if left is positive and right is negative, left is greater, return 1
  if (!left.neg) {
    if (right.neg) return 1;
    // is both values are pos, and |left| > |right|, left is greater, return 1
    if ( (left.whole > right.whole) || ( (left.whole == right.whole) && (left.frac > right.frac) )) return 1;
    // else, right is greater, return -1
    return -1;
  }

  // if right is positive, only option left is that left is negative. right is greater, return -1 
  if (!right.neg) return -1;

  // both values must be neg to reach this point, if |left| < |right|, left is greater, return 1
  if ( (left.whole < right.whole) || ( (left.whole == right.whole) && (left.frac < right.frac) )) return 1;
  // else return -1
  return -1;
}

int fixedpoint_is_zero(Fixedpoint val) {
  return (val.whole == 0 && val.frac == 0);
}

int fixedpoint_is_err(Fixedpoint val) {
  return val.err;
}

int fixedpoint_is_neg(Fixedpoint val) {
  return val.neg;
}

int fixedpoint_is_overflow_neg(Fixedpoint val) {
  return val.neg_over;
}

int fixedpoint_is_overflow_pos(Fixedpoint val) {
  return val.pos_over;
}

int fixedpoint_is_underflow_neg(Fixedpoint val) {
  return val.neg_under;
}

int fixedpoint_is_underflow_pos(Fixedpoint val) {
  return val.pos_under;
}

int fixedpoint_is_valid(Fixedpoint val) {
  return !(val.err || val.pos_over || val.neg_over || val.pos_under || val.neg_under);
}

char *fixedpoint_format_as_hex(Fixedpoint val) {
  char* hex = calloc(35, 1);
  unsigned int i = 0;
  unsigned int *i_ptr = &i;

  if (fixedpoint_is_zero(val)) {
    hex[i] = '0';
    hex[i + 1] = '\0';
    return hex;
  }

  if (fixedpoint_is_neg(val)) { 
    hex[i] = '-';
    i++;
  }
  
  if (val.whole) dec_to_hex(val.whole, hex, i_ptr, 1);
  else {
    hex[i] = '0';
    i++;
  }

  if (val.frac) dec_to_hex(val.frac, hex, i_ptr, 0);
  hex[i] = '\0';

  return hex;
}

void dec_to_hex(uint64_t val, char *hex, unsigned int* index, int whole) {
  int hex_int, non_zero = 0;
  char hex_char;
  uint64_t rem = val;

  if (!whole) {
    hex[*index] = '.';
    (*index)++;
  }

  for (int j = 15; j >= 0; j--) {
    if (rem == 0 && !whole) return;

    hex_int = (rem >> (4 * j)) & 15;
    rem -= (rem >> (4 * j)) << (4 * j);

    if (!non_zero && hex_int) non_zero = 1;
    if (hex_int > 9) hex_char = 'a' + hex_int - 10;
    else hex_char = '0' + hex_int;

    if (non_zero || !whole) {
      hex[*index] = hex_char;
      (*index)++;
    }
  }
}

uint64_t hex_to_dec(const char *hex, int len, int is_whole, int* err) {
  uint64_t val = 0;
  int i = is_whole ? 0 : 15;

  if (len > 16) *err = 1;

  for (int j = 0; j < len; ++j) {
    if (*hex >= '0' && *hex <= '9') val += (1UL << (4 * i)) * (*hex - '0');

    else if (*hex >= 'a' && *hex <= 'f') val += (1UL << (4 * i)) * (*hex - 'a' + 10);
    else if (*hex >= 'A' && *hex <= 'F') val += (1UL << (4 * i)) * (*hex - 'A' + 10);

    else *err = 1;

    if (is_whole) { --hex; ++i; }
    else { ++hex; --i; }
  }

  return val;
}

uint64_t get_add_val(uint64_t val1, uint64_t val2, uint64_t* carry) {
  // initialize variables
  uint64_t sum;
  uint64_t temp;
  // if both 64th bits are 1, set them to zero, do addition with modified values, and remember to carry over later
  if ((val1 >> 63) && (val2 >> 63)) {
    *carry = 1;
    sum = (val1 ^ (1UL << 63)) + (val2 ^ (1UL << 63));
  }
  else if ((val1 >> 63) || (val2 >> 63)) {
    if (val2 >> 63) {
      temp = val1;
      val1 = val2;
      val2 = temp;
    }
    
    sum = (val1 ^ (1UL << 63)) + val2;
    if (sum >> 63) {
      sum = sum ^ (1UL << 63);
      *carry = 1;
    }
    else sum = val1 + val2;
  }
  else sum = val1 + val2;

  return sum;
}
