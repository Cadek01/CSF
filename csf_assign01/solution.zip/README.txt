Rohit Sivananthan, Mason Albert

We both worked together on finishing the fixedpoint_create, fixedpoint_create2, fixedpoint_whole_part, fixedpoint_frac_part, and the fixedpoint_is_zero functions. Mason physically typed up the fixedpoint_create functions, fixedpoint_whole_part, and fixedpoint_frac_part. I typed up the fixedpoint_create and fixedpoint_is_zero functions.


